package com.cesi.romain.sudoku;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class GrilleViewHolder {
    public TextView Level;
    public TextView Numero;
    public TextView Pourcent;
}
